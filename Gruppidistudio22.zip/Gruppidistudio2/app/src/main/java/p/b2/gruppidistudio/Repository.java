package p.b2.gruppidistudio;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

import static p.b2.gruppidistudio.Chat.am_pm;
import static p.b2.gruppidistudio.MainActivity.displayName;

public class Repository extends AppCompatActivity {
    private static final String TAG = "Repository";
    //return request code from photo picker activity for result
    private static final int RC_FILE_PICKER =  222;
    private String file_ext;
    private long fileSize;
    private String fileDisplayName;
    private String data_to_upload_string;
    private Uri data_to_upload;
    private ListView mMessageListView;
    private MessageAdapter mMessageAdapter;
    private TextView textViewUploads;
    private ProgressBar mProgressBar;
    private ImageButton mFilePickerButton;
    private EditText mMessageEditText;
    private Button mUploadButton;
    private String mUsername;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessagesDatabaseReference;
    private ChildEventListener mChildEventListener;
    private FirebaseStorage mFirebaseStorage;
    private StorageReference mChatFilesStorageReference;
    private String materia;
    private String materia_est;
    private EditText mEditText;
    private View.OnClickListener mUploadButtonListener;
    private LinearLayout messageLayout;
    private int anno;
    private ArrayList<ChatMessage> chatMessages;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_layout);
        mUsername=displayName;
        Intent intent=getIntent();
        materia=intent.getExtras().getString("materia");
        materia_est=intent.getExtras().getString("materia_est");
        anno=intent.getExtras().getInt("anno");
        //INITIALIZE FIREBASE
        mFirebaseDatabase=FirebaseDatabase.getInstance();
        mFirebaseStorage=FirebaseStorage.getInstance();
        mMessagesDatabaseReference=mFirebaseDatabase.getReference().child(materia+"_docs");
        mChatFilesStorageReference=mFirebaseStorage.getReference().child(materia+"_files");
        attachDatabaseReadListener();
        // Initialize references to views

        mProgressBar = findViewById(R.id.progressBar);
        mMessageListView =findViewById(R.id.messageListView);
        mFilePickerButton =findViewById(R.id.photoPickerButton);
        //modifichiamo un pezzo di layout
        mFilePickerButton.setBackgroundResource(android.R.drawable.ic_menu_save);
        mMessageEditText =findViewById(R.id.messageEditText);
        //nascondiamo editText
        mMessageEditText.setVisibility(View.INVISIBLE);
        mUploadButton =findViewById(R.id.sendButton);
        //modifichiamo un altro pezzo di layout
        mUploadButton.setText("Upload");
        mUploadButton.setVisibility(View.INVISIBLE);
        mUploadButtonListener=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isOnline()){
                    Toast.makeText(Repository.this,"You are not connected to Internet",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                mMessagesDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int mutex=0;
                        for( DataSnapshot snapshot :dataSnapshot.getChildren()){
                            if(snapshot.child("text").getValue(String.class).substring(0,snapshot.child("text").getValue(String.class).lastIndexOf(".")).equals(mMessageEditText.getText().toString().toUpperCase())){
                                Toast.makeText(Repository.this,"The file with this name already exists",Toast.LENGTH_SHORT).show();
                                mutex=1;
                                break;
                            }
                        }
                        if(mutex==0)
                            uploadFile(data_to_upload);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }

                });
            }
        };
        mUploadButton.setOnClickListener(mUploadButtonListener);
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mUploadButton.setEnabled(true);
                } else {
                    mUploadButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });


        // Initialize message ListView and its adapter

        chatMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, chatMessages);
        mMessageListView.setAdapter(mMessageAdapter);
        mMessageListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            // setting onItemLongClickListener and passing the position to the function
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int position, long arg3) {
                if(!isOnline()){
                    Toast.makeText(Repository.this,"You are not connected to Internet",
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
                ChatMessage msg=chatMessages.get(position);
                if(msg.getName().equals(displayName)){
                    mMessagesDatabaseReference.child(msg.getMsg_id()).removeValue();
                    mFirebaseStorage.getReferenceFromUrl(msg.getFileUrl()).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "onSuccess: deleted file");
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Uh-oh, an error occurred!
                            Log.d(TAG, "onFailure: did not delete file");
                        }
                    });
                    removeItemFromList(position);
                }
                return true;
            }
        });

        mMessageListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(!isOnline()){
                    Toast.makeText(Repository.this,"You are not connected to Internet",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                ChatMessage upload=chatMessages.get(i);
                Intent target = new Intent(Intent.ACTION_VIEW);
                target.setDataAndType(Uri.parse(upload.getFileUrl()),"application/pdf");
                target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);

                //Intent intent = Intent.createChooser(target, "Open File");
                try {
                    startActivity(target);
                } catch (ActivityNotFoundException e) {
                    // Instruct the user to install a PDF reader here, or something
                    Toast.makeText(Repository.this,"Install a pdf reader",Toast.LENGTH_SHORT).show();
                }

            }
        });


        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mFilePickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setType("application/pdf");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, RC_FILE_PICKER);
            }
        });

    }

    private void detachDataBaseListener() {
        if(mChildEventListener!=null) {
            mMessagesDatabaseReference.removeEventListener(mChildEventListener);
            mChildEventListener=null;
        }
    }

    private void attachDatabaseReadListener() {
        if(mChildEventListener==null) {
            mChildEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    ChatMessage chatMessage = dataSnapshot.getValue(ChatMessage.class);
                    mMessageAdapter.add(chatMessage);
                }
                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }
                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) { }
                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) { }
            };
            mMessagesDatabaseReference.addChildEventListener(mChildEventListener);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem chat = menu.findItem(R.id.chat);
        chat.setVisible(true);
        MenuItem signout=menu.findItem(R.id.sign_out_menu);
        signout.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.chat:
                Intent intent1=new Intent(this,Chat.class);
                intent1.putExtra("materia",materia);
                intent1.putExtra("materia_est",materia_est);
                intent1.putExtra("anno",anno);
                startActivity(intent1);
                return true;
            default:return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == RC_FILE_PICKER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            //if a file is selected
            if (data.getData() != null) {
                data_to_upload=data.getData();
                data_to_upload_string=data_to_upload.toString();
                File myFile = new File(data_to_upload_string);
                mUploadButton.setVisibility(View.VISIBLE);

                mMessageEditText.setVisibility(View.VISIBLE);
                if (data_to_upload_string.startsWith("content://")) {
                    Cursor cursor = null;
                    try {
                        cursor = Repository.this.getContentResolver().query(data_to_upload, null, null, null, null);
                        if (cursor != null && cursor.moveToFirst()) {
                            fileDisplayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                            fileSize=(long)cursor.getInt(cursor.getColumnIndex(OpenableColumns.SIZE))/1000;

                        }
                    } finally {
                        cursor.close();
                    }
                } else
                    if(data_to_upload.toString().startsWith("file://")) {
                    fileDisplayName = myFile.getName();
                    fileSize=myFile.length();
                }
                file_ext=fileDisplayName.substring(fileDisplayName.lastIndexOf("."));
                mMessageEditText.setText(fileDisplayName);
                //uploadFile(data.getData());
            }else{
                Toast.makeText(this, "No file chosen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void uploadFile(Uri data) {
        //https://stackoverflow.com/questions/24322738/android-how-to-get-selected-file-name-from
        // -the-document
        mUploadButton.setVisibility(View.INVISIBLE);
        final StorageReference sRef = mChatFilesStorageReference.child(mMessageEditText.getText().toString());
        final UploadTask uploadTask = sRef.putFile(data);
        mProgressBar.setVisibility(View.VISIBLE);

        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }

                // Continue with the task to get the download URL
                return sRef.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    Calendar now=Calendar.getInstance();
                    if(now.get(Calendar.AM_PM)==1){
                        am_pm="PM";
                    }
                    String qualcosa_bytes=" KB";
                    if(fileSize/1000>1){
                        qualcosa_bytes=" MB";
                        fileSize/=1000;
                    }
                    String msg_id=mMessagesDatabaseReference.push().getKey();
                    ChatMessage chatMessage =new ChatMessage(mMessageEditText.getText().toString().toUpperCase()+file_ext,mUsername,
                            null,downloadUri.toString(),""+fileSize+""+qualcosa_bytes,
                            ""+now.get(Calendar.HOUR)+":"+now.get(Calendar.MINUTE)+" "+am_pm,
                            ""+now.get(Calendar.DAY_OF_MONTH)+"/"+(now.get(Calendar.MONTH)+1)+"/"+now.get(Calendar.YEAR),msg_id);
                    mMessagesDatabaseReference.child(msg_id).setValue(chatMessage);
                    mProgressBar.setVisibility(View.GONE);
                    mMessageEditText.setText("");
                    mMessageEditText.setVisibility(View.GONE);
                } else {
                    // Handle failures
                    // ...
                }
            }
        });
    }


    protected void onStart(){
        super.onStart();
        if(materia.equals("1") || materia.equals("2") || materia.equals("3"))
            Toast.makeText(Repository.this, "Benvenuto nella repository del "+materia_est + " della triennale"
                    ,Toast.LENGTH_SHORT).show();
        else if (materia.equals("trien"))
            Toast.makeText(Repository.this, "Benvenuto nella repository della "+materia_est, Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(Repository.this,"Benvenuto nella repository del corso di "+materia_est+"!"
                    ,Toast.LENGTH_SHORT ).show();
    }

    protected void onPause (){
        super.onPause();
    }

    protected void onResume(){
        super.onResume();
    }
    public void onBackPressed(){
        super.onBackPressed();
        Intent intent=new Intent(Repository.this,Chat.class);
        intent.putExtra("materia",materia);
        intent.putExtra("materia_est",materia_est);
        intent.putExtra("anno",anno);
        startActivity(intent);
    }
    protected void removeItemFromList(int position) {
        final int deletePosition = position;

        AlertDialog.Builder alert = new AlertDialog.Builder(
                Repository.this);

        alert.setTitle("Delete");
        alert.setMessage("Do you want delete this item?");
        alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                chatMessages.remove(deletePosition);
                mMessageAdapter.notifyDataSetChanged();

            }
        });
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        alert.show();

    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}