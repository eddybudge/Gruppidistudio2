package p.b2.gruppidistudio;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Anno extends AppCompatActivity {

    String primo[]={"analisi","arch_el1","arch_el2","disc_mat1","disc_mat2","prog1","prog2","ling"};
    String primo_est[]={"Analisi Matematica","Architettura di Elaboratori 1","Architettura di Elaboratori2"
            ,"Matematica Discreta 1","Matematica Discreta 2","Programmazione 1","Programmazione 2","Lingua Inglese"};
    String secondo[]={"alg","prob","calc","ing_sof","dir_inf","ling_for","sis_op","fis"};
    String secondo_est[]={"Algoritmi e Strutture Dati","Probabilità e Statistica","Calcolo Numerico"
            ,"Ingegneria del Software","Diritto dell'informatica","Linguaggi Formali","Sistemi Operativi","Fisica"};
    String terzo[]={"db","arc_re","tec_acq","sis_mult","proto","sis_ape","prog3","rea_virt"};
    String terzo_est[]={"Basi di Dati","Architettura Reti","Tecniche di acquisizione Dati", "Sistemi Multimediali",
            "Reti di Calcolatori: Protocolli","Sistemi Aperti e Distribuiti", "Programmazione 3", "Linguaggi di Realtà Virtuale"};
    Button btn[];

    private final String materia="materia";
    private final String materia_est="materia_est";
    private int anno,l,i,btn_id;
    private String anno_est;
    //array "contenitori"
    String anno_della_tri[],anno_della_tri_est[];
    LinearLayout linearLayout;
    LayoutInflater inflater;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        anno=getIntent().getExtras().getInt("anno");
        setContentView(R.layout.anno);
        linearLayout=findViewById(R.id.linearLayout);
        inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        switch(anno){
            case 1:
                l=primo.length;
                anno_della_tri=primo;
                anno_della_tri_est=primo_est;
                anno_est="I anno";
                break;
            case 2:
                l=secondo.length;
                anno_della_tri=secondo;
                anno_della_tri_est=secondo_est;
                anno_est="II anno";
                break;
            case 3:
                l=terzo.length;
                anno_della_tri=terzo;
                anno_della_tri_est=terzo_est;
                anno_est="III anno";
                break;
            default:
                l=primo.length;
                anno_della_tri=primo;
                anno_della_tri_est=primo_est;
                break;
        }
        btn=new Button[l];

        for(i=0;i<l;i++) {
            btn[i]=(Button)inflater.inflate(R.layout.button_corso,linearLayout,false);
            btn[i].setText(anno_della_tri_est[i]);
            btn_id=getResources().getIdentifier(anno_della_tri[i],"id"
                    ,"p.b2.gruppidistudio");
            btn[i].setId(btn_id);
            btn[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Anno.this, Chat.class);
                    int k=linearLayout.indexOfChild(view);
                    intent.putExtra(materia, anno_della_tri[k]);
                    intent.putExtra(materia_est, anno_della_tri_est[k]);
                    intent.putExtra("anno",anno);
                    startActivity(intent);
                }
            });
            linearLayout.addView(btn[i]);
        }
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem chat = menu.findItem(R.id.chat);
        chat.setVisible(true);
        MenuItem signout = menu.findItem(R.id.sign_out_menu);
        signout.setVisible(false);
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.chat:
                Intent intent1=new Intent(this,Chat.class);
                intent1.putExtra("materia",String.valueOf(anno));
                intent1.putExtra("materia_est",anno_est);
                intent1.putExtra("anno",anno);
                startActivity(intent1);
                return true;
            default:return super.onOptionsItemSelected(item);
        }
    }
    //TODO aggiungere la chat per anno e la triennale
    public void onBackPressed(){
        super.onBackPressed();
        Intent intent=new Intent(Anno.this,MainActivity.class);
        startActivity(intent);
    }

}
