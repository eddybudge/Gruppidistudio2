package p.b2.gruppidistudio;


public class ChatMessage {

    private String text;
    private String name;
    private String photoUrl;
    private String fileUrl;
    private String fileSize;
    private String time;
    private String day;
    private String msg_id;

    public ChatMessage() {
    }

    public ChatMessage(String text, String name, String photoUrl, String fileUrl, String fileSize , String time, String day, String msg_id) {
        this.text = text;
        this.name = name;
        this.photoUrl = photoUrl;
        this.fileUrl =fileUrl;
        this.fileSize=fileSize;
        this.time=time;
        this.day=day;
        this.msg_id=msg_id;

    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {

        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMsg_id() {
        return msg_id;
    }

    public void setMsg_id(String msg_id) {
        this.msg_id = msg_id;
    }
}
