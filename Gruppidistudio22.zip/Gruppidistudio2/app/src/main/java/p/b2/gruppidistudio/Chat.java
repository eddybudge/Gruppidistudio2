package p.b2.gruppidistudio;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static p.b2.gruppidistudio.MainActivity.displayName;

public class  Chat extends AppCompatActivity{
    private static final String TAG = "Chat";
    //return request code from photo picker activity for result
    private static final int RC_PHOTO_PICKER =  2;
    private static final int DEFAULT_MSG_LENGTH_LIMIT = 1000;

    private ArrayList<ChatMessage> chatMessages;
    private ListView mMessageListView;
    private MessageAdapter mMessageAdapter;
    private ProgressBar mProgressBar;
    private ImageButton mPhotoPickerButton;
    private EditText mMessageEditText;
    private Button mSendButton;
    private String mUsername;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mMessagesDatabaseReference;
    private ChildEventListener mChildEventListener;
    private FirebaseStorage mFirebaseStorage;
    private StorageReference mChatPhotosStorageReference;
    private String materia;
    private String materia_est;
    public static String am_pm="AM";
    private String anno_est;
    private int anno;
    private String msg_id;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_layout);

        mUsername=displayName;

        Intent intent=getIntent();
        materia=intent.getExtras().getString("materia");
        materia_est=intent.getExtras().getString("materia_est");
        anno=intent.getExtras().getInt("anno");
        anno_est= intent.getExtras().getString("anno_est");
        //INITIALIZE FIREBASE
        mFirebaseDatabase=FirebaseDatabase.getInstance();
        mFirebaseStorage=FirebaseStorage.getInstance();
        mMessagesDatabaseReference=mFirebaseDatabase.getReference().child(materia);
        mChatPhotosStorageReference=mFirebaseStorage.getReference().child(materia+"_photos");
        attachDatabaseReadListener();
        // Initialize references to views
        mProgressBar = findViewById(R.id.progressBar);
        mMessageListView = findViewById(R.id.messageListView);
        mPhotoPickerButton = findViewById(R.id.photoPickerButton);
        mMessageEditText = findViewById(R.id.messageEditText);
        mSendButton = findViewById(R.id.sendButton);

        // Initialize message ListView and its adapter
        chatMessages = new ArrayList<>();
        mMessageAdapter = new MessageAdapter(this, R.layout.item_message, chatMessages);
        mMessageListView.setAdapter(mMessageAdapter);
        mMessageListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ChatMessage message=chatMessages.get(i);
                if(message.getPhotoUrl()!=null){
                    Intent target = new Intent(Intent.ACTION_VIEW);
                    target.setDataAndType(Uri.parse(message.getPhotoUrl()),"image/*");
                    target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                    try {
                        startActivity(target);
                    }
                    catch (ActivityNotFoundException e) {
                        Toast.makeText(Chat.this,"Install a photo viewer",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        mMessageListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            // setting onItemLongClickListener and passing the position to the function
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int position, long arg3) {
                if(!isOnline()){
                    Toast.makeText(Chat.this,"You are not connected to Internet",
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
                ChatMessage msg=chatMessages.get(position);
                if(msg.getName().equals(displayName)) {
                    mMessagesDatabaseReference.child(msg.getMsg_id()).removeValue();
                    if(msg.getPhotoUrl()!=null){
                        mFirebaseStorage.getReferenceFromUrl(msg.getPhotoUrl()).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "onSuccess: deleted file");
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Uh-oh, an error occurred!
                                Log.d(TAG, "onFailure: did not delete file");
                            }
                        });
                    }
                    removeItemFromList(position);
                }
                return true;
            }
        });

        // Initialize progress bar
        mProgressBar.setVisibility(ProgressBar.INVISIBLE);

        // ImagePickerButton shows an image picker to upload a image for a message
        mPhotoPickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/jpeg");
                // an implementation should only allow the user to select data that is already on
                // the device, not requiring it be downloaded from a remote service when opened.
                intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
                startActivityForResult(intent,RC_PHOTO_PICKER);
            }
        });

        // Enable Send button when there's text to send
        mMessageEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().trim().length() > 0) {
                    mSendButton.setEnabled(true);
                } else {
                    mSendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        mMessageEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(DEFAULT_MSG_LENGTH_LIMIT)});

        // Send button sends a message and clears the EditText
        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isOnline()){
                    Toast.makeText(Chat.this,"You are not connected to Internet",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                Calendar now=Calendar.getInstance();
                if(now.get(Calendar.AM_PM)==1){
                    am_pm="PM";
                }
                msg_id=mMessagesDatabaseReference.push().getKey();
                ChatMessage chatMessage = new ChatMessage(mMessageEditText.getText()
                        .toString(), mUsername, null ,null,null,
                        ""+now.get(Calendar.HOUR)+":"+now.get(Calendar.MINUTE)+" "+am_pm,
                        ""+now.get(Calendar.DAY_OF_MONTH)+"/"+(now.get(Calendar.MONTH)+1)+"/"+now.get(Calendar.YEAR),msg_id);
                mMessagesDatabaseReference.child(msg_id).setValue(chatMessage);
                // Clear input box
                mMessageEditText.setText("");
            }
        });
    }

    private void detachDataBaseListener() {
        if(mChildEventListener!=null) {
            mMessagesDatabaseReference.removeEventListener(mChildEventListener);
            mChildEventListener=null;
        }
    }

    private void attachDatabaseReadListener() {
        if(mChildEventListener==null) {
            mChildEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    ChatMessage chatMessage = dataSnapshot.getValue(ChatMessage.class);
                    mMessageAdapter.add(chatMessage);
                }
                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }
                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) { }
                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) { }
            };
            mMessagesDatabaseReference.addChildEventListener(mChildEventListener);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem docs = menu.findItem(R.id.mat_di);
        docs.setVisible(true);
        MenuItem signout=menu.findItem(R.id.sign_out_menu);
        signout.setVisible(false);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.mat_di:
                //access documents
                Intent intent2=new Intent (Chat.this,Repository.class);
                intent2.putExtra("materia",materia);
                intent2.putExtra("materia_est",materia_est);
                intent2.putExtra("anno",anno);
                startActivity(intent2);
                return true;
            default:return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==RC_PHOTO_PICKER && resultCode==RESULT_OK){
            Uri selected_image_uri=data.getData();
            final StorageReference photo_ref=mChatPhotosStorageReference.child(
                    selected_image_uri.getLastPathSegment());
            UploadTask uploadTask = photo_ref.putFile(selected_image_uri);
            mProgressBar.setVisibility(View.VISIBLE);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    // Continue with the task to get the download URL
                    //task implicito
                    return photo_ref.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        Calendar now=Calendar.getInstance();
                        if(now.get(Calendar.AM_PM)==1){
                            am_pm="PM";
                        }
                        msg_id=mMessagesDatabaseReference.push().getKey();
                        ChatMessage chatMessage =new ChatMessage(null,mUsername,
                                downloadUri.toString(),null,null,
                                ""+now.get(Calendar.HOUR)+":"+now.get(Calendar.MINUTE)+" "+am_pm,
                                ""+now.get(Calendar.DAY_OF_MONTH)+"/"+(now.get(Calendar.MONTH)+1)+"/"+now.get(Calendar.YEAR),msg_id);
                        mMessagesDatabaseReference.child(msg_id).setValue(chatMessage);
                        mProgressBar.setVisibility(View.GONE);
                    } else {
                        // Handle failures
                        // ...
                    }
                }
            });
        }
    }
    //Starting with Google Play services version 9.0.0, you can use a Task API and a number of methods
    // that return Task or its subclasses. Task is an API that represents asynchronous method
    // calls

    //public Task<TContinuationResult> continueWithTask (Continuation<TResult, Task<TContinuationResult>> continuation)
    //
    //Returns a new Task that will be completed with the result of applying the specified Continuation to this Task.
    //
    //The Continuation will be called on the main application thread.

    // public interface Continuation
    //
    //A function that is called to continue execution after completion of a Task.

    protected void onStart(){
        super.onStart();
        if(materia.equals("1") || materia.equals("2") || materia.equals("3"))
            Toast.makeText(Chat.this, "Benvenuto nella chat del "+materia_est + " della triennale"
                    ,Toast.LENGTH_SHORT).show();
        else if (materia.equals("trien"))
            Toast.makeText(Chat.this, "Benvenuto nella chat della "+materia_est, Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(Chat.this,"Benvenuto nella chat del corso di "+materia_est+"!"
                ,Toast.LENGTH_SHORT ).show();
    }

    protected void onPause (){
        super.onPause();
    }

    protected void onResume(){
        super.onResume();
    }

    public void onBackPressed(){
        super.onBackPressed();
        if(materia.equals("trien")){
            Intent intent=new Intent(Chat.this,MainActivity.class);
            startActivity(intent);
            return;
        }
        Intent intent=new Intent(Chat.this,Anno.class);
        intent.putExtra("anno",anno);
        startActivity(intent);
    }

    protected void removeItemFromList(int position) {
        final int deletePosition = position;

        AlertDialog.Builder alert = new AlertDialog.Builder(
                Chat.this);

        alert.setTitle("Delete");
        alert.setMessage("Do you want delete this item?");
        alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TOD O Auto-generated method stub

                // main code on after clicking yes

                chatMessages.remove(deletePosition);
                mMessageAdapter.notifyDataSetChanged();
                //Notifies the attached observers that the underlying data has been changed and
                // any View reflecting the data set should refresh itself.

            }
        });
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                dialog.dismiss();
            }
        });

        alert.show();

    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }
}
