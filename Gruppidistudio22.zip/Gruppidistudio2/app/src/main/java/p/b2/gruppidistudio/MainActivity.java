package p.b2.gruppidistudio;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.firebase.ui.auth.AuthUI;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.util.Arrays;


public class MainActivity extends AppCompatActivity {
    //arbitrary request code needed for "start activity for result" (sign in):it's a flag for
    // identifying the result intent when we return from the activityForResult
    private static final int RC_SIGN_IN = 123;
    public static FirebaseAuth mFirebaseAuth;
    public static FirebaseAuth.AuthStateListener mAuthStateListener;
    Button Ianno,IIanno,IIIanno;
    public static String displayName;
    LinearLayout mainLinearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ianno=findViewById(R.id.Ianno);
        IIanno=findViewById(R.id.IIanno);
        IIIanno=findViewById(R.id.IIIanno);
        mainLinearLayout=findViewById(R.id.mainLinearLayout);
        mFirebaseAuth=FirebaseAuth.getInstance();

        mAuthStateListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user=firebaseAuth.getCurrentUser();
                if(user!=null){
                    displayName=user.getDisplayName();
                    //user is signed in
                }else{
                    //user is signed out
                    //smartlock allows to save users' credentials and make them access automatically
                    startActivityForResult(
                            AuthUI.getInstance()
                                    .createSignInIntentBuilder()
                                    .setIsSmartLockEnabled(false)
                                    .setAvailableProviders(Arrays.asList(
                                            new AuthUI.IdpConfig.EmailBuilder().build()
                                    )).build(),RC_SIGN_IN);
                }
            }
        };


        Ianno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Anno.class);
                intent.putExtra("anno",1);
                startActivity(intent);
            }
        });

        IIanno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Anno.class);
                intent.putExtra("anno",2);
                startActivity(intent);
            }
        });

        IIIanno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Anno.class);
                intent.putExtra("anno",3);
                startActivity(intent);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==RC_SIGN_IN){
            if(resultCode==RESULT_OK){
                Toast.makeText(MainActivity.this, "You are now signed in." +
                        "Welcome to Gruppi di Studio!",Toast.LENGTH_SHORT).show();
            }else if(resultCode==RESULT_CANCELED){
                Toast.makeText(MainActivity.this,"Signed in cancelled!",Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem chat = menu.findItem(R.id.chat);
        chat.setVisible(true);
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.sign_out_menu:
                //sign out;
                AuthUI.getInstance().signOut(getApplicationContext());
                return true;
            case R.id.chat:
                Intent intent1=new Intent(this,Chat.class);
                intent1.putExtra("materia","trien");
                intent1.putExtra("materia_est","della Laurea Triennale in Informatica");
                startActivity(intent1);
                return true;
            default:return super.onOptionsItemSelected(item);
        }

    }

    protected void onPause (){
        super.onPause();
        //we detach the listener because we want to avoid multiple instances of it when we
        //are going back and forth from foreground to background
        mFirebaseAuth.removeAuthStateListener(mAuthStateListener);
    }

    protected void onResume(){
        super.onResume();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

    public void onBackPressed(){
        super.onBackPressed();
        finish();
    }
}
