package p.b2.gruppidistudio;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.Calendar;
import java.util.List;

public class MessageAdapter extends ArrayAdapter<ChatMessage> {
    public MessageAdapter(Context context, int resource, List<ChatMessage> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            //TODO || if ch_msg contains a photo -> inflate a new view and do not reuse the view that has been already created...
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.item_message, parent, false);
        }

        ImageView photoImageView = convertView.findViewById(R.id.photoImageView);
        TextView messageTextView = convertView.findViewById(R.id.messageTextView);
        TextView authorTextView =convertView.findViewById(R.id.nameTextView);
        TextView fileSizeView=convertView.findViewById(R.id.sizeTextView);
        TextView timeView=convertView.findViewById(R.id.dateTextView);
        TextView dayView=convertView.findViewById(R.id.dayTextView);

        ChatMessage message = getItem(position);
        fileSizeView.setVisibility(View.INVISIBLE);
        dayView.setVisibility(View.VISIBLE);
        dayView.setText(message.getDay());

        if (message.getPhotoUrl() != null) {
            messageTextView.setVisibility(View.GONE);
            photoImageView.setVisibility(View.VISIBLE);
            //Glide’s primary focus is on making scrolling any kind of a list of images as smooth and fast as possible, but Glide is also effective for almost any case where you need to fetch, resize, and display a remote image.
            Glide.with(convertView.getContext())
                    .load(message.getPhotoUrl())
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    //DiskCacheStrategy.SOURCE caches only the original full-resolution image.
                    .into(photoImageView);
        } else {
            messageTextView.setVisibility(View.VISIBLE);

            if(message.getFileUrl()==null) {
                photoImageView.setVisibility(View.GONE);
                messageTextView.setText(message.getText());
            }
            else{
                fileSizeView.setVisibility(View.VISIBLE);
                fileSizeView.setText(String.valueOf(message.getFileSize()));
                photoImageView.setVisibility(View.INVISIBLE);
                messageTextView.setBackgroundColor(Color.parseColor("#f9c459"));
                messageTextView.setText(message.getText().toUpperCase().substring(0,message.getText().lastIndexOf(".")));
            }

        }
        Calendar now=Calendar.getInstance();
        if((""+now.get(Calendar.DAY_OF_MONTH)+"/"+(now.get(Calendar.MONTH)+1)+"/"+now.get(Calendar.YEAR)).equals(message.getDay()))
            dayView.setVisibility(View.INVISIBLE);
        timeView.setText(message.getTime());
        authorTextView.setText(message.getName());

        return convertView;
    }
}
